package app;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ContactService {
	private List<Contact> contacts;

	public ContactService() {
		// Initializes contacts list as ArrayList
		this.contacts = new ArrayList<>(); 
	}

	// Validates contact information
	private void validateContactFields(Contact contact) {
		// Goes through each contact in the ArrayList to determine if contact id is in use.
		for (Contact contactList : contacts) {
			if (contactList.getContactId().equals(contact.getContactId())) {
				throw new IllegalArgumentException("Duplicate contact ID");
			}
		}
		// Tries to validate information, throws exception if invalid
		try {
			contact.setContactId(contact.getContactId());
			contact.setFirstName(contact.getFirstName());
			contact.setLastName(contact.getLastName());
			contact.setPhone(contact.getPhone());
			contact.setAddress(contact.getAddress());
		} catch (IllegalArgumentException e) {
			throw new IllegalArgumentException("Invalid contact fields");
		}
	}

	// Add new contact to contact list
	public void addContact(Contact contact) {
		validateContactFields(contact);
		contacts.add(contact);

	}

	// Deletes contact from contact list based on contact id
	public void deleteContact(String contactId) {
		
		// Use iterator to go through contact list
		Iterator<Contact> iterator = contacts.iterator(); 
		while (iterator.hasNext()) {
			Contact contact = iterator.next();
			if (contact.getContactId().equals(contactId)) {
				iterator.remove(); // Remove contact if it matches contact id
				return;
			}
		}
		throw new IllegalArgumentException("Contact ID not found");
	}

	// Updates a specific field based on contact id and user option.
	public void updateContactField(String contactId, String option,
			String newInfo) {
		Contact contact = getContactById(contactId);
		if (contact != null) {
			// Update the field based on contact id
			// Tries to set new field info and throws exception if invalid
			switch (option) {
				case "firstName" :
					try {
						contact.setFirstName(newInfo);
					} catch (IllegalArgumentException e) {
						throw new IllegalArgumentException(
								"Invalid first name");
					}
					break;
				case "lastName" :
					try {
						contact.setLastName(newInfo);
					} catch (IllegalArgumentException e) {
						throw new IllegalArgumentException("Invalid last name");
					}

					break;
				case "phone" :
					try {
						contact.setPhone(newInfo);
					} catch (IllegalArgumentException e) {
						throw new IllegalArgumentException(
								"Invalid phone number");
					}
					break;
				case "address" :
					try {
						contact.setAddress(newInfo);
					} catch (IllegalArgumentException e) {
						throw new IllegalArgumentException("Invalid address");
					}

					break;
				default :
					throw new IllegalArgumentException("Invalid selection");
			}
		} else {
			throw new IllegalArgumentException("Contact ID not found");
		}
	}

	// Retrieve contact based on contact id
	public Contact getContactById(String contactId) {
		for (Contact contact : contacts) {
			if (contact.getContactId().equals(contactId)) {
				return contact;
			}
		}
		return null; // Contact not found
	}

}