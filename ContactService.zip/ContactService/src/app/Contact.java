package app;

public class Contact {
	
	// declare variables
	private String contactId;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;

	// Constructs a Contact object with contact id, first name, last name, phone, and address
	public Contact(String contactId, String firstName, String lastName,
			String phone, String address) {
		// Makes sure contact id is valid before setting it
		if (contactId == null || contactId.length() > 10) {
			throw new IllegalArgumentException("Invalid contacta ID");
		}
		// Makes sure first name is valid before setting it
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid first name");
		}
		// Makes sure last name is valid before setting it
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid last name");
		}
		// Makes sure phone number is valid before setting it
		if (phone == null || phone.length() != 10) {
			throw new IllegalArgumentException("Invalid phone number");
		}
		// Makes sure address is valid before setting it
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid address");
		}

		// assign values to variables
		this.contactId = contactId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.address = address;

	}

	// Returns contact id
	public String getContactId() {
		return contactId;
	}

	// Sets contact id
	public void setContactId(String contactId) {
		// Makes sure contact id is valid before setting it
		if (contactId == null || contactId.length() > 10) {
			throw new IllegalArgumentException("Invalid contact ID");
		} else {
			this.contactId = contactId;
		}
	}

	// Returns first name
	public String getFirstName() {
		return firstName;
	}

	// Sets first name
	public void setFirstName(String firstName) {
		// Makes sure first name is valid before setting it
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid first name");
		} else {
			this.firstName = firstName;
		}
	}

	// Returns last name
	public String getLastName() {
		return lastName;
	}

	// Sets last name
	public void setLastName(String lastName) {
		// Makes sure last name is valid before setting it
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid last name");
		} else {
			this.lastName = lastName;
		}
	}

	// Return phone number
	public String getPhone() {
		return phone;
	}

	// Sets phone number
	public void setPhone(String phone) {
		// Makes sure phone number is valid before setting it
		if (phone == null || phone.length() != 10) {
			throw new IllegalArgumentException("Invalid phone number");
		} else {
			this.phone = phone;
		}
	}

	// Returns address
	public String getAddress() {
		return address;
	}

	// Sets address
	public void setAddress(String address) {
		// Makes sure address is valid before setting it
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid address");
		} else {
			this.address = address;
		}

	}
}