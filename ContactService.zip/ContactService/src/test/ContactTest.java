package test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import app.Contact;


public class ContactTest {

	private Contact contact;
	
    @BeforeEach
    public void setUp() {
        contact = new Contact("1", "Matt", "Smith", "3049207432", "717 Clifford");
    }
	
    @Test
    @DisplayName("Tests valid contact creation")
    public void testValidContactCreation() {
    	Assertions.assertEquals("1", contact.getContactId());
    	Assertions.assertEquals("Matt", contact.getFirstName());
    	Assertions.assertEquals("Smith", contact.getLastName());
    	Assertions.assertEquals("3049207432", contact.getPhone());
    	Assertions.assertEquals("717 Clifford", contact.getAddress());
    }
    
    @Test
    @DisplayName("Test constructor with invalid arguments")
    public void testInvalidContructorArguments() {
        // Test invalid contact ID
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678910", "Matt", "Smith", "3049207432", "717 Clifford");
        });

        // Test invalid first name
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Matthew William", "Smith", "3049207432", "717 Clifford");
        });

        // Test invalid last name
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Matt", "William Smith", "3049207432", "717 Clifford");
        });

        // Test invalid phone number
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Matt", "Smith", "84746630777", "717 Clifford");
        });

        // Test invalid address
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Matt", "Smith", "3049207432", "2500 North River Road Manchester, NH 03106");
        });
    }
    
    @Test
    @DisplayName("Tests setters work")
    public void testValidSetters() {

        contact.setContactId("1");
        contact.setFirstName("Matt");
        contact.setLastName("Smith");
        contact.setPhone("3049207432");
        contact.setAddress("717 Clifford");

        Assertions.assertEquals("1", contact.getContactId());
        Assertions.assertEquals("Matt", contact.getFirstName());
        Assertions.assertEquals("Smith", contact.getLastName());
        Assertions.assertEquals("3049207432", contact.getPhone());
        Assertions.assertEquals("717 Clifford", contact.getAddress());
    }

    @Test
    @DisplayName("Test invalid contact ID")
    public void testInvalidContactId() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setContactId("12345678910"); // Sets first name to more than 10 characters
        });

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setContactId(null); // Sets first name to null value
        });

    }
    @Test
    @DisplayName("Tests invalid first name")
    public void testInvalidFirstName() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setFirstName("Matthew William"); // Sets first name to more than 10 characters
        });

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setFirstName(null); // Sets first name to null value
        });
    }

    @Test
    @DisplayName("Tests invalid last name")
    public void testInvalidLastName() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName("William Smith"); // Sets last name to more than 10 characters
        });

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName(null); // Sets last name to null value
        });
    }
        
    @Test	
    @DisplayName("Tests invalid phone number")
    public void testInvalidPhone() {   
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    		contact.setPhone("84746630777"); // Sets phone number to more than 10 characters
    	});
    	
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    		contact.setPhone(null); // Sets phone number to null value
    	});
    }
    
    @Test	
    @DisplayName("Tests invalid address")
    public void testInvalidAddress() {   
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    		contact.setAddress("2500 North River Road Manchester, NH 03106"); // Sets phone number to more than 10 characters
    	});
    	
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    		contact.setAddress(null); // Sets phone number to null value
    	});
    }
}