package test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import app.Contact;
import app.ContactService;

public class ContactServiceTest {

    private ContactService contactService;

    @BeforeEach
    @DisplayName("Sets up contactservice for each test")
    public void setup() {
        contactService = new ContactService();
    }

    @Test
    @DisplayName("Tests adding a contact with a unique ID")
    public void testAddContactWithUniqueID() {
        Contact contact = new Contact("1", "Matt", "Smith", "5555675309", "717 Clifford");
        contactService.addContact(contact);
        
        Contact retrievedContact = contactService.getContactById("1");
        Assertions.assertEquals("Matt", retrievedContact.getFirstName());
        Assertions.assertEquals("Smith", retrievedContact.getLastName());
        Assertions.assertEquals("5555675309", retrievedContact.getPhone());
        Assertions.assertEquals("717 Clifford", retrievedContact.getAddress());
         
    }
    
    @Test
    @DisplayName("Tests adding a contact with a non-unique ID")
    public void testAddContactWithNonUniqueID() {
        Contact contact = new Contact("1", "Matt", "Smith", "5555675309", "717 Clifford");
        contactService.addContact(contact);
        
        Contact contact2 = new Contact("1", "Diana", "Smith", "5555675308", "717 Clifford");

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contactService.addContact(contact2);
        });
    }

    @Test
    @DisplayName("Tests deleting a contact")
    public void testDeleteContact() {
        Contact contact = new Contact("1", "Matt", "Smith", "5558675309", "717 Clifford");
        contactService.addContact(contact);

        contactService.deleteContact("1");
        Contact retrievedContact = contactService.getContactById("1");
        Assertions.assertNull(retrievedContact);
    }
    
    @Test
    @DisplayName("Tests deleting an invalid contact")
    public void testDeleteInvalidContact() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contactService.deleteContact("nonexistent");
        });
    }

    @Test
    @DisplayName("Tests updating contact fields")
    public void testUpdateContactFields() {
        Contact contact = new Contact("1", "Matt", "Smith", "5555675309", "717 Clifford");
        contactService.addContact(contact);

        // Updates first name
        contactService.updateContactField("1", "firstName", "Diana");
        Contact updatedContact = contactService.getContactById("1");
        Assertions.assertEquals("Diana", updatedContact.getFirstName());

        // Updates last name
        contactService.updateContactField("1", "lastName", "Smith");
        updatedContact = contactService.getContactById("1");
        Assertions.assertEquals("Smith", updatedContact.getLastName());

        // Updates phone number
        contactService.updateContactField("1", "phone", "5558675307");
        updatedContact = contactService.getContactById("1");
        Assertions.assertEquals("5558675307", updatedContact.getPhone());

        // Updates address
        contactService.updateContactField("1", "address", "862 Pinehurst");
        updatedContact = contactService.getContactById("1");
        Assertions.assertEquals("862 Pinehurst", updatedContact.getAddress());
    }
    
    @Test
    @DisplayName("Tests updating contact fields with invalid inputs")
    public void testUpdateInvalidContactFields() {
        Contact contact = new Contact("1", "Matt", "Smith", "5555675309", "717 Clifford");
        contactService.addContact(contact);

        // Test invalid contact id
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	contactService.updateContactField("2", "firstName", "Matt");
        });
        
        // Test invalid selection
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	contactService.updateContactField("1", "FIRSTNAME", "Matt");
        });
        
        // Updates first name over ten characters
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	contactService.updateContactField("1", "firstName", "DianaSmith1");
        });

        // Updates last name over ten characters
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	contactService.updateContactField("1", "lastName", "WilliamSmith");
        });

        // Updates phone number that isnt ten digits
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContactField("1", "phone", "565");
        });

        // Updates address
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	contactService.updateContactField("1", "address", "2500 North River Road Manchester, NH 03106");
        });

    }
}